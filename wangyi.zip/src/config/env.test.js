module.exports = {
  title: 'vue-h5-template',
  baseUrl: 'https://test.xxx.com', // test 测试项目地址
  baseApi: 'https://test.xxx.com/api', // test 测试api请求地址
  APPID: 'xxx',
  APPSECRET: 'xxx',
  $cdn: 'https://imgs.solui.cn',
  desc: '测试环境'
}
