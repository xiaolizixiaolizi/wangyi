<template>
  <div class="home">
    <img alt="Vue logo" src="~assets/logo.png">
    <h3>home组件</h3>
  </div>
</template>

<script>

export default {
  name: 'Home',
  components: {
  }
}
</script>
<style lang="scss" scoped>
h3 {
  color: $mainCcolor;
}
</style>
