{
  const str = './news.js'
  console.log(str)
  console.log(str.split('./')[1].split('.')[0])
}
